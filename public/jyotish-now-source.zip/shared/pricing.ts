/**
 * Canonical price list, shared by the browser and the order endpoint.
 *
 * This is the single source of truth: the page renders prices from here and
 * /api/create-order charges from here. The browser sends a service + variant
 * key, never an amount, so a tampered request cannot change what is charged.
 *
 * Contains no secrets — safe to bundle into the client.
 */

export type ServiceId =
  | "consultation-call"
  | "couple-consultation"
  | "face-to-face"
  | "baby-muhurat";

export type Service = {
  label: string;
  /** Variant key -> price in whole rupees. "default" for single-price services. */
  variants: Record<string, number>;
};

export const SERVICES: Record<ServiceId, Service> = {
  "consultation-call": {
    label: "Consultation Call",
    variants: {
      "30 Min|Audio": 2599,
      "30 Min|Video": 2999,
      "1 Hour|Audio": 4599,
      "1 Hour|Video": 4999,
    },
  },
  "couple-consultation": {
    label: "Couple Consultation",
    variants: {
      "30 Min|Audio": 4599,
      "30 Min|Video": 4999,
      "1 Hour|Audio": 7599,
      "1 Hour|Video": 7999,
    },
  },
  "face-to-face": {
    label: "Face to Face Consultation",
    variants: { default: 21000 },
  },
  "baby-muhurat": {
    label: "Baby Birth Muhurat",
    variants: { default: 11000 },
  },
};

export const DEFAULT_VARIANT = "default";

/** Returns the price in rupees, or null when the service/variant is unknown. */
export const getPriceInRupees = (
  service: string,
  variant: string = DEFAULT_VARIANT,
): number | null => {
  const entry = SERVICES[service as ServiceId];
  if (!entry) return null;
  const price = entry.variants[variant];
  return typeof price === "number" ? price : null;
};

export const getServiceLabel = (service: string): string | null =>
  SERVICES[service as ServiceId]?.label ?? null;

export const formatINR = (rupees: number) =>
  `₹${rupees.toLocaleString("en-IN")}`;
